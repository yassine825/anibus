<?php
session_start();

if(!isset($_SESSION['medecin'])){
header("Location: login_medecin.html");
exit();
}

$conn = new mysqli("localhost","root","","clinique");

$sql="SELECT * FROM rendezvous";
$result=$conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>

<title>Espace Médecin</title>
<link rel="stylesheet" href="style_medecin.css">

</head>

<body>

<header>

<h2>Espace Médecin</h2>

<div>
<a href="logout.php">Déconnexion</a>
</div>

</header>


<h2>Gestion des Rendez-vous</h2>

<table>

<tr>
<th>Patient</th>
<th>Téléphone</th>
<th>Email</th>
<th>Date</th>
<th>Heure</th>
<th>Symptômes</th>
<th>Action</th>
</tr>

<?php

while($row=$result->fetch_assoc()){

echo "<tr>";

echo "<td>".$row['nom']."</td>";
echo "<td>".$row['telephone']."</td>";
echo "<td>".$row['email']."</td>";
echo "<td>".$row['date']."</td>";
echo "<td>".$row['heure']."</td>";
echo "<td>".$row['symptomes']."</td>";

echo "<td>

<a class='btn confirm' href='confirmer.php?id=".$row['id']."'>Confirmer</a>

<a class='btn delete' href='supprimer.php?id=".$row['id']."'>Annuler</a>

</td>";

echo "</tr>";

}

?>

</table>

</body>
</html>