<?php

$conn = new mysqli("localhost","root","","clinique");

if($conn->connect_error){
die("connexion échouée");
}

$medecin = $_POST['medecin'];
$nom = $_POST['nom'];
$telephone = $_POST['telephone'];
$email = $_POST['email'];
$heure = $_POST['heure'];
$symptomes = $_POST['symptomes'];

$sql = "INSERT INTO rendezvous 
(medecin, nom, telephone, email, heure, symptomes)
VALUES 
('$medecin','$nom','$telephone','$email','$heure','$symptomes')";

if($conn->query($sql)){
echo "Rendez-vous confirmé";
}
else{
echo "Erreur";
}

$conn->close();

?>